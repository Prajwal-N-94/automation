package com.spiceJet.test;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.spicejet.pages.BookingPage;

import resources.Base;

public class HomepageTest extends Base {
	private static Logger log = LogManager.getLogger(Base.class.getName());

	@BeforeTest
	public void initialize() throws IOException {
		driver = initializeDriver();
		driver.get(prop.getProperty("url"));
		log.info("driver initialized successfully");
	}

	@Test
	public void invokeHome() throws IOException {

		BookingPage l = new BookingPage(driver);

		// Selecting the checkbox
		log.debug("Selecting the senior citizen");
		l.clickCheckbox().click();
		log.info("Checked on the checbox successfully");

		// Clicking on the from field
		log.debug("Clicking on the check field");
		l.clickFromField().click();
		log.info("Successfully clicked on the from field");

		// Selecting the 'from city'
		log.debug("Selecting the 'from city'");
		l.selectFromCity().click();
		log.info("Successfully selected the city");

		// Selecting the 'destination city'
		log.debug("Selecting the 'from city'");
		l.selectDestiCity().click();
		log.info("Successfully selected the destination city");

		// get the count of days for the present month
		int count = l.getDaysCount();
		log.info(l.getDaysCount());

		// iterating through all the days
		for (int i = 0; i < count; i++) {

			String dates = l.getDates().get(i).getText();
			// System.out.println(dates);
			String datevalue = prop.getProperty("bookingdate");
			if (dates.equalsIgnoreCase(datevalue)) {
				l.selectDate().get(i).click();
				log.info("Successfully clicked on the desired day");
				break;
			}
			log.error("Could not find the desired date");
		}
		// using select for the dropdowns
		Select s = new Select(l.selectCurrency());
		log.debug("selecting the currency type");
		s.selectByValue(prop.getProperty("currencytype"));
		log.info("Successfully selected currency type");

		l.submit().click();
		log.info("Successfully clicked on the go button");
	}

	@AfterTest
	public void tearDown() {
		driver.close();
		driver=null;
		log.info("Successfully closed the browser");

	}
}
